let msg : string = "hello world";
console.log(msg);
document.body.textContent = msg;