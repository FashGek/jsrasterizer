


let frame_count = 0;
let frame_time = 0;
let last_frame_time = 0;
let rst = new Rasteriszer(800, 600);
let canvas = new Canvas(800, 600);


function now() {
    return new Date().getTime();
}

last_frame_time = now();


function get_model_matrix(angle) {

    /*
    angle = angle * math.pi / 180.0;

    // 绕y轴旋转
    let rotation = math.matrix([
        [math.cos(angle), 0, math.sin(angle), 0],
        [0, 1, 0, 0],
        [-math.sin(angle), 0, math.cos(angle), 0],
        [0, 0, 0, 1]
    ]
    );

    let s = 2.5;
    let scale = math.matrix([
        [s,0, 0, 0],
        [0, s, 0, 0],
        [0, 0, s, 0],
        [0, 0, 0, 1]
    ]
    );

    let translate = math.matrix([
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, 1]
    ]
    );

    return math.multiply(translate, math.multiply(rotation, scale));*/

    return math.identity(4, 4);
}

function get_view_matrix(eye_pos) {

    
    let view = math.identity(4, 4);

    let translate = math.matrix([
        [1, 0, 0, -eye_pos[0]],
        [0, 1, 0, -eye_pos[1]],
        [0, 0, 1, -eye_pos[2]],
        [0, 0, 0, 1]
    ]
    )

    return math.multiply(translate, view);
}


function get_projection_matrix(eye_fov, aspect_ratio, zNear, zFar) {


    let projection = math.identity(4, 4);

    let t = zNear * math.tan(eye_fov / 2);
    let b = -t;
    let r = t * aspect_ratio;
    let l = -r;

    let ortho = math.matrix([
        [2 / (r - l), 0, 0, (r + l) / (l - r)],
        [0, 2 / (t-b), 0, (t+b)/(b-t)],
        [0, 0, 2./(zFar - zNear), (zFar + zNear) / (zNear - zFar)],
        [0, 0, 0, 1]
    ]
    );

    let proj_to_ortho = math.matrix([
        [-zNear, 0, 0, 0],
        [0, -zNear, 0, 0],
        [0, 0, -(zNear + zFar), -zNear * zFar],
        [0, 0, 1, 0]
        ]
    );

    return math.multiply(ortho, proj_to_ortho)
}


function render() {
    frame_count += 1;

    angle = 0;

    eye_pos = [0, 0, 5];
    
    pos = [
        [2, 0, -2],
        [0, 2, -2],
        [-2, 0, -2],
        [3.5, -1, -5],
        [2.5, 1.5, -5],
        [-1, 0.5, -5]
    ];

    ind = [
        [0, 1, 2],
        [3, 4, 5]
    ];

    cols = [
        [217.0, 238.0, 185.0],
        [217.0, 238.0, 185.0],
        [217.0, 238.0, 185.0],
        [185.0, 217.0, 238.0],
        [185.0, 217.0, 238.0],
        [185.0, 217.0, 238.0],
    ]

    let pos_id = rst.load_pos(pos);
    let ind_id = rst.load_indicies(ind);
    let col_id = rst.load_colors(cols);

    rst.clear();
    rst.set_model(get_model_matrix(angle));
    rst.set_view(get_view_matrix(eye_pos));
    rst.set_projection(get_projection_matrix(45.0, 1, 0.1, 50));

    // rst.draw(pos_id, ind_id, col_id, 0);


    // frame buffer to canvas

    canvas.write_pixels(rst.frame_buf);


    console.log("frame count = ", frame_count, " delta time = ", now() - last_frame_time);
    last_frame_time = now();
    // nomater how long rasterizer one image, after render finisehd we delay 10
    /*setTimeout(() => {
        render();
    }, 1000);*/
}




document.addEventListener("DOMContentLoaded", function(event) { 
    canvas.init('main');
    render();
});

